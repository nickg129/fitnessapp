(function(window, undefined) {
  var dictionary = {
    "cb7ad6c0-fb0e-4c57-925d-b5973af48a01": "Setup-0",
    "828034b3-b54c-46d1-bcca-c0bcc041e4b9": "Setup -3",
    "9584028b-d17a-431e-812c-35b5922eac9c": "Setup -2",
    "0b4bde50-f128-4ede-8477-b5905cf7ffd3": "Setup -1",
    "034a23e2-8c35-49e5-89e8-b55e3838b61a": "Home",
    "0d7d27f7-8dd2-43f4-9a4e-748b95aaa1b3": "Home -4",
    "d12245cc-1680-458d-89dd-4f0d7fb22724": "Login",
    "ae3e5e9b-a244-4d97-b158-065f8f67fd28": "Home -3",
    "956df61d-9861-435f-8edd-bf20cbade6e8": "Home -2",
    "7bd6cbd9-5599-4ca0-b93b-e53e8e8eef55": "Home -1",
    "87db3cf7-6bd4-40c3-b29c-45680fb11462": "960 grid - 16 columns",
    "e5f958a4-53ae-426e-8c05-2f7d8e00b762": "960 grid - 12 columns",
    "f39803f7-df02-4169-93eb-7547fb8c961a": "Template 1",
    "bb8abf58-f55e-472d-af05-a7d1bb0cc014": "default"
  };

  var uriRE = /^(\/#)?(screens|templates|masters|scenarios)\/(.*)(\.html)?/;
  window.lookUpURL = function(fragment) {
    var matches = uriRE.exec(fragment || "") || [],
        folder = matches[2] || "",
        canvas = matches[3] || "",
        name, url;
    if(dictionary.hasOwnProperty(canvas)) { /* search by name */
      url = folder + "/" + canvas;
    }
    return url;
  };

  window.lookUpName = function(fragment) {
    var matches = uriRE.exec(fragment || "") || [],
        folder = matches[2] || "",
        canvas = matches[3] || "",
        name, canvasName;
    if(dictionary.hasOwnProperty(canvas)) { /* search by name */
      canvasName = dictionary[canvas];
    }
    return canvasName;
  };
})(window);