(function(window, undefined) {

  var jimLinks = {
    
  }

  window.jimLinks = jimLinks;
})(window);